//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by rk_provision_tool.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_RK_PROVISION_TOOL_DIALOG    102
#define IDR_HTML_DLGITEMCMN             103
#define IDR_MAINFRAME                   128
#define IDR_MENU1                       129
#define IDD_DLG_SETTINGS                130
#define IDD_ITEM_CMN                    131
#define IDB_BITMAP_GREEN                132
#define IDB_BITMAP_RED                  133
#define IDC_STATIC_SN                   1000
#define IDC_STATIC_WIFI                 1001
#define IDC_STATIC_LAN                  1002
#define IDC_STATIC_BT                   1003
#define IDC_STATIC_IMEI                 1004
#define IDC_EDIT_SN                     1005
#define IDC_EDIT_WIFI                   1006
#define IDC_EDIT_LAN                    1007
#define IDC_EDIT_BT                     1008
#define IDC_EDIT_IMEI                   1009
#define IDC_LIST_RESULT                 1010
#define IDC_BUTTON_READ                 1011
#define IDC_BUTTON_WRITE                1012
#define IDC_RADIO_S                     1013
#define IDC_TAB_ITEM                    1015
#define IDC_STATIC_START                1019
#define IDC_STATIC_COUNT                1020
#define IDC_STATIC_CURRENT              1021
#define IDC_STATIC_LEFT                 1022
#define IDC_EDIT_START                  1023
#define IDC_EDIT_CURRENT                1024
#define IDC_EDIT_LEFT                   1026
#define IDC_EDIT_COUNT                  1027
#define IDC_STATIC_PREFIX               1028
#define IDC_STATIC_SUFFIX               1029
#define IDC_EDIT_PREFIX                 1030
#define IDC_EDIT_SUFFIX                 1031
#define IDC_COMBO1                      1033
#define IDC_COMBO_TYPE                  1033
#define IDC_COMBO_LAN                   1033
#define IDC_STATIC_AUDO                 1034
#define IDC_EDIT_ID                     1035
#define IDC_CHECK_SN                    1038
#define IDC_CHECK_WIFI                  1039
#define IDC_CHECK_IMEI                  1040
#define IDC_CHECK_BT                    1041
#define IDC_CHECK_LAN                   1042
#define IDC_CHECK_ENABLE                1043
#define IDC_STATIC_FILE                 1044
#define IDC_EDIT2                       1045
#define IDC_EDIT_FILE                   1045
#define IDC_EDIT_MASKROM                1045
#define IDC_CHECK_SINGLE                1046
#define IDC_STATIC_DEVICES              1047
#define IDC_PICTURE_DEVICE              1048
#define IDC_EDIT_LOADER                 1049
#define IDC_STATIC_LOADER               1050
#define IDC_CHECK_LOADER                1051
#define IDC_BUTTON_TEST                 1052
#define IDC_CHECK_FORCE_MASKROM         1055
#define IDC_BUTTON1                     1056
#define IDC_BUTTON_BROW_LOADER          1056
#define IDC_CHECK_COMPAT                1057
#define IDC_CHECK_REBOOT                1058
#define IDC_BUTTON2                     1059
#define IDC_BUTTON_REBOOT               1059
#define IDC_CHECK_RPMB                  1060
#define IDC_CHECK1                      1061
#define IDC_CHECK_LOCK                  1061
#define ID_32771                        32771
#define ID_32772                        32772
#define ID_MENU_ABOUT                   32773
#define ID_MENU_SETTINGS                32774
#define ID_32775                        32775
#define ID_MENU_LOG                     32776

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        134
#define _APS_NEXT_COMMAND_VALUE         32777
#define _APS_NEXT_CONTROL_VALUE         1062
#define _APS_NEXT_SYMED_VALUE           104
#endif
#endif
