#include "stdafx.h"
#include "cmLog.h"
#include "cmIniFile.h"
#include "cmMultiLanguage.h"
#include "cmPath.h"
#include "cmFile.h"
#include "cmNumString.h"
#include "cmCommonDlg.h"
#include "cmStrCode.h"
#include "cmSpawn.h"
#include "cmAlgorithm.h"
using namespace cm;
#include "DefineHeader.h"
#include "RKScan.h"
#include "RKComm.h"
#include "RKImage.h"
#include "RKUpgrade.h"
#include "RKDevice.h"
#include "RK28Device.h"
#include "RKNanoDevice.h"
#include "RKAndroidDevice.h"
#include "afxwin.h"
#include "BtnST.h"
#include "XGroupBox.h"
#include "FontStatic.h"
#include "ColumnTreeCtrl.h"
#include "VirtualGridCtrl.h"
#include "MySpawnConsumer.h"
#include <cfgmgr32.h>
#include "rksluvc_utils.h"

#define MAX_DEVICEID_SIZE	512

int CM_Get_Childs_Count(STRUCT_RKDEVICE_DESC &parent)
{
	int count = 0;
	DWORD dwNextInst, dwDeviceInstance;
	CONFIGRET ret;

	ret = CM_Get_Child((LPDWORD)&dwNextInst, parent.dwDeviceInstance, 0);
	while (ret == CR_SUCCESS) {
		count ++;
		dwDeviceInstance = dwNextInst;
		ret = CM_Get_Sibling(&dwNextInst, dwDeviceInstance, 0);
	}
	return count;
}

BOOL IsCompositeDevice(DWORD devInst)
{
	CONFIGRET ret;
	ULONG ulBufSize=0;
	ULONG ulRegType=REG_MULTI_SZ;
	BYTE *pBuf=NULL;

	ret = CM_Get_DevNode_Registry_Property(devInst,CM_DRP_COMPATIBLEIDS,&ulRegType,pBuf,&ulBufSize,0);
	if ((ret != CR_SUCCESS)&&(ret != CR_BUFFER_SMALL)) {
		return FALSE;
	}
	pBuf = new BYTE[ulBufSize];
	if (!pBuf) {
		return FALSE;
	}
	ret = CM_Get_DevNode_Registry_Property(devInst,CM_DRP_COMPATIBLEIDS,&ulRegType,pBuf,&ulBufSize,0);
	if (ret != CR_SUCCESS) {
		return FALSE;
	}
	BOOL bFound=FALSE;
 	PWCHAR pPos=(PWCHAR)pBuf;
	PWCHAR pStart = pPos;
	CString strID=_T("");

 	while(pPos < (pStart + ulBufSize)) {
		if (*pPos != 0) {
			strID += *pPos;
		} else {
			if (strID.Find(_T("COMPOSITE"))!=-1) {
				bFound = TRUE;
				break;
			} else
				strID = _T("");
			
			if (*(pPos+1) == 0) {
				break;
			}
		}
		pPos++;
 	}
	delete [] pBuf;
	return bFound;
}

BOOL CM_Get_Childs(DWORD dwInstance, TCHAR *szFriendlyName, TCHAR *DeviceID, DWORD dwLen)
{
	DWORD dwNextInst, dwDeviceInstance;
	CONFIGRET ret;
	CString strInfo;
	DWORD len;
	BOOL Found = FALSE;

	dwDeviceInstance = dwInstance;
	ret = CM_Get_Child((LPDWORD)&dwNextInst, dwDeviceInstance, 0);
	if (ret == CR_SUCCESS) {
		dwDeviceInstance = dwNextInst;
		do {
			len = MAX_DEVICEID_SIZE;
			ret = CM_Get_DevNode_Registry_Property(dwDeviceInstance, CM_DRP_FRIENDLYNAME, NULL, strInfo.GetBuffer(len), &len, 0);
			strInfo.ReleaseBuffer();
			if (ret == CR_SUCCESS) {
				strInfo.MakeUpper();
				if (NULL != _tcsstr(strInfo.GetString(), szFriendlyName)) {
					ret = CM_Get_Device_ID(dwDeviceInstance, DeviceID, dwLen, 0);
					if (ret == CR_SUCCESS) {
						Found = TRUE;
						break;
					} else {
						break;
					}
				}
			} else {
				break;
			}
			ret = CM_Get_Sibling(&dwNextInst, dwDeviceInstance, 0);
			if (ret == CR_SUCCESS) {
				dwDeviceInstance = dwNextInst;
			} else {
				break;
			}
		} while(1);
	}
	return Found;
}

BOOL UVCSwitchToLoader(STRUCT_RKDEVICE_DESC *dev, ENUM_RKUSB_TYPE type)
{
	BOOL bRet = FALSE;
	BYTE data[60] = {0};
	int size;
	DWORD dwDeviceInstance;
	CString strDeviceID;
	CONFIGRET ret;

	ret = CM_Get_Parent(&dwDeviceInstance, dev->dwDeviceInstance, 0);
	if (ret != CR_SUCCESS) {
		return FALSE;
	}
	if (!IsCompositeDevice(dwDeviceInstance)) {
		return FALSE;
	}
	/* find rgb instance */
	bRet = CM_Get_Childs(dwDeviceInstance, TEXT("UVC RGB"), strDeviceID.GetBuffer(MAX_DEVICEID_SIZE), MAX_DEVICEID_SIZE);
	strDeviceID.ReleaseBuffer();
	if (!bRet) {
		return FALSE;
	}
	strDeviceID.Replace(_T('\\'),_T('#'));
	strDeviceID.MakeLower();
	size = 4;
	switch (type) {
	default:
	case RKUSB_NONE:
	case RKUSB_MASKROM:
		*((DWORD*)data) = 0xFFFFFFFE; /* reboot */
		break;
	case RKUSB_LOADER:
		*((DWORD*)data) = 0xFFFFFFFF; /* reboot */
		break;
	case RKUSB_ADB:
		*((DWORD*)data) = 0xFFFFFFEB; /* enable adb  */
		break;
	}
	if(extension_cmd(strDeviceID.GetString(), 1, data, size)) {
		bRet = TRUE;
	} else {
		bRet = FALSE;
	}
	return bRet;
}