#ifndef DEFINE_HEADER
#define DEFINE_HEADER

#include <winioctl.h>

#include <list>
#include <vector>
#include <set>
#include <string>
#include <algorithm>
#include <sstream>
#include <map>
using namespace std;
#ifdef _M_AMD64
#undef DWORD
#define DWORD UINT
#endif
#if defined(_UNICODE) || defined(UNICODE)
typedef wstring	tstring;
typedef wstringstream tstringstream;
#else
typedef string	tstring;
typedef stringstream tstringstream;
#endif
#ifndef PROP
#define PROP(T,X) __declspec(property(get=Get##X,put=Set##X))T X;//��д����
#define GETPROP(T,X) __declspec(property(get=Get##X))T X; //ֻ������
#define SETPROP(T,X) __declspec(property(put=Set##X))T X; //ֻд����
#define GET(T,X) T Get##X() 
#define SET(T,X) VOID Set##X(T value)
#endif
#define MSC_CHIPINFO_NUM 13
CONST char MSC_CHIPINFO_SET[MSC_CHIPINFO_NUM][16]={
	"RK28",
	"RK281X",
	"RKPANDA",
	"RKCROWN",
	"RKNANO",
	"RKNANOB",
	"RKSMART",
	"RKCAYMAN",
	"RK29",
	"RK292X",
	"RK30",
	"RK31",
	"RK32"
};
CONST TCHAR MSC_CHIPINFO_SET_TCHAR[MSC_CHIPINFO_NUM][16]={
	_T("RK28"),
	_T("RK281X"),
	_T("RKPANDA"),
	_T("RKCROWN"),
	_T("RKNANO"),
	_T("RKNANOB"),
	_T("RKSMART"),
	_T("RKCAYMAN"),
	_T("RK29"),
	_T("RK292X"),
	_T("RK30"),
	_T("RK31"),
	_T("RK32")
};

typedef enum
{
		RKNONE_DEVICE=0,
		RK27_DEVICE=0x10,
		RKCAYMAN_DEVICE,
		RK28_DEVICE=0x20,
		RK281X_DEVICE,
		RKPANDA_DEVICE,
		RKNANO_DEVICE=0x30,
		RKSMART_DEVICE,
		RKCROWN_DEVICE=0x40,
		RK29_DEVICE=0x50,
		RK292X_DEVICE,
		RK30_DEVICE=0x60,
		RK30B_DEVICE,
		RK31_DEVICE=0x70,
		RK32_DEVICE=0x80
}ENUM_RKDEVICE_TYPE;
typedef enum
{
		RK_OS=0,
		ANDROID_OS=0x1
}ENUM_OS_TYPE;
typedef enum {
		FS_NONE=0,
		FS_CRAMFS,
		FS_CRAMFS_ENCRYPT
}ENUM_FS_TYPE;
typedef enum
{
		RKUSB_NONE=0x0,
		RKUSB_MASKROM=0x01,
		RKUSB_LOADER=0x02,
		RKUSB_MSC=0x04,
		RKUSB_ADB=0x08,
		RKUSB_MTP=0x10,
		RKUSB_UVC=0x20
}ENUM_RKUSB_TYPE;
typedef enum
{
		ENTRY471=1,
		ENTRY472=2,
		ENTRYLOADER=4
}ENUM_RKBOOTENTRY;
#define  MSC_ANDROID_OPER 0xFF

typedef enum
{
	MSC_NONE_OPER=0x0,
	MSC_FORMAT_OPER=0x1,
	MSC_COPY_OPER=0x2,
	MSC_FORMAT_DATA_OPER=0x4,
	MSC_COPY_DATA_OPER=0x8
}ENUM_MSC_OPER;
typedef enum
{
	MISC_MODIFY_NONE=0,
	MISC_MODIFY_WIPE_ALL,
	MISC_MODIFY_WIPE_DATA,
}ENUM_MISC_MODIFY_FLAG;
typedef enum
{
	WF_UPGRADE=1,
	WF_RESTORE,
	WF_GETOLDDISKSIZE,
	WF_READSN,
	WF_WRITESN,
	WF_ERASEFLASH,
	WF_ERASEIDB,
	WF_GETBLOCKSTATE,
	WF_READMAC,
	WF_WRITEMAC,
	WF_READBT,
	WF_WRITEBT,
	WF_READIMEI,
	WF_WRITEIMEI,
	WF_READUID,
	WF_READCUSTOMDATA,
	WF_WRITECUSTOMDATA,
	WF_READALLINFO,
	WF_WRITEALLINFO,
	WF_DOWNLOADBOOT,
	WF_READWIFI,
	WF_WRITEWIFI,
	WF_CLEARALLINFO
}ENUM_WORKFLOW;
#pragma pack(1)
typedef struct sparse_header_t {
  UINT	magic;		/* 0xed26ff3a */
  USHORT	major_version;	/* (0x1) - reject images with higher major versions */
  USHORT	minor_version;	/* (0x0) - allow images with higer minor versions */
  USHORT	file_hdr_sz;	/* 28 bytes for first revision of the file format */
  USHORT	chunk_hdr_sz;	/* 12 bytes for first revision of the file format */
  UINT	blk_sz;		/* block size in bytes, must be a multiple of 4 (4096) */
  UINT	total_blks;	/* total blocks in the non-sparse output image */
  UINT	total_chunks;	/* total chunks in the sparse input image */
  UINT	image_checksum; /* CRC32 checksum of the original data, counting "don't care" */
				/* as 0. Standard 802.3 polynomial, use a Public Domain */
				/* table implementation */
} sparse_header;

#define SPARSE_HEADER_MAGIC	0xed26ff3a
#define UBI_HEADER_MAGIC	0x23494255
#define CHUNK_TYPE_RAW		0xCAC1
#define CHUNK_TYPE_FILL		0xCAC2
#define CHUNK_TYPE_DONT_CARE	0xCAC3
#define CHUNK_TYPE_CRC32    0xCAC4

typedef struct chunk_header_t {
  USHORT	chunk_type;	/* 0xCAC1 -> raw; 0xCAC2 -> fill; 0xCAC3 -> don't care */
  USHORT	reserved1;
  UINT	chunk_sz;	/* in blocks in output image */
  UINT	total_sz;	/* in bytes of chunk input file including chunk header and data */
} chunk_header;

/* Following a Raw or Fill or CRC32 chunk is data.
 *  For a Raw chunk, it's the data in chunk_sz * blk_sz.
 *  For a Fill chunk, it's 4 bytes of the fill data.
 *  For a CRC32 chunk, it's 4 bytes of CRC32
 */
typedef struct  
{
	USHORT usYear;
	UCHAR  ucMonth;
	UCHAR  ucDay;
	UCHAR  ucHour;
	UCHAR  ucMinute;
	UCHAR  ucSecond;
}STRUCT_RKTIME,*PSTRUCT_RKTIME;
typedef struct _STRUCT_RKDEVICE_DESC
{
	USHORT usVid;
	USHORT usPid;
	TCHAR  szDrive;
	USHORT usbcdUsb;
	DWORD  dwDeviceInstance;
	CString strLinkName;
	CString strLayer;
	ENUM_RKUSB_TYPE emUsbType;
	ENUM_RKDEVICE_TYPE emDeviceType;
	BOOL bUsb20;
}STRUCT_RKDEVICE_DESC,*PSTRUCT_RKDEVICE_DESC;
#pragma pack()
typedef list<STRUCT_RKDEVICE_DESC> RKDEVICE_DESC_SET;
typedef RKDEVICE_DESC_SET::iterator device_list_iter;
typedef vector<CString> STRING_VECTOR;
typedef enum
{
		DOWNLOADBOOT_START=1,
		DOWNLOADBOOT_FAIL=2,
		DOWNLOADBOOT_PASS=3,
		DOWNLOADIDBLOCK_START=4,
		DOWNLOADIDBLOCK_FAIL=5,
		DOWNLOADIDBLOCK_PASS=6,
		DOWNLOADIMAGE_START=7,
		DOWNLOADIMAGE_FAIL=8,
		DOWNLOADIMAGE_PASS=9,
		TESTDEVICE_START=10,
		TESTDEVICE_FAIL=11,
		TESTDEVICE_PASS=12,
		RESETDEVICE_START=13,
		RESETDEVICE_FAIL=14,
		RESETDEVICE_PASS=15,
		FORMATDISK_START=16,
		FORMATDISK_FAIL=17,
		FORMATDISK_PASS=18,
		COPYDATA_START=19,
		COPYDATA_FAIL=20,
		COPYDATA_PASS=21,
		WAITMSC_START=22,
		WAITMSC_FAIL=23,
		WAITMSC_PASS=24,
		WAITLOADER_START=25,
		WAITLOADER_FAIL=26,
		WAITLOADER_PASS=27,
		WAITMASKROM_START=28,
		WAITMASKROM_FAIL=29,
		WAITMASKROM_PASS=30,
		ERASEIDB_START=31,
		ERASEIDB_FAIL=32,
		ERASEIDB_PASS=33,
		SWITCHMSC_START=34,
		SWITCHMSC_FAIL=35,
		SWITCHMSC_PASS=36,
		CHECKCHIP_START=37,
		CHECKCHIP_FAIL=38,
		CHECKCHIP_PASS=39,
		PREPAREIDB_START=40,
		PREPAREIDB_FAIL=41,
		PREPAREIDB_PASS=42,
		MUTEXRESETDEVICE_START=43,
		MUTEXRESETDEVICE_FAIL=44,
		MUTEXRESETDEVICE_PASS=45,
		GETOLDDISKSIZE_START=46,
		GETOLDDISKSIZE_FAIL=47,
		GETOLDDISKSIZE_PASS=48,
		READSN_START=49,
		READSN_FAIL=50,
		READSN_PASS=51,
		WRITESN_START=52,
		WRITESN_FAIL=53,
		WRITESN_PASS=54,
		ERASEALLBLOCKS_START=55,
		ERASEALLBLOCKS_FAIL=56,
		ERASEALLBLOCKS_PASS=57,
		GETBLOCKSTATE_START=58,
		GETBLOCKSTATE_FAIL=59,
		GETBLOCKSTATE_PASS=60,
		GETFLASHINFO_START=61,
		GETFLASHINFO_FAIL=62,
		GETFLASHINFO_PASS=63,
		WRITEBACK_START=64,
		WRITEBACK_FAIL=65,
		WRITEBACK_PASS=66,
		FINDUSERDISK_START=67,
		FINDUSERDISK_FAIL=68,
		FINDUSERDISK_PASS=69,
		SHOWUSERDISK_START=70,
		SHOWUSERDISK_FAIL=71,
		SHOWUSERDISK_PASS=72,
		READMAC_START=73,
		READMAC_FAIL=74,
		READMAC_PASS=75,
		WRITEMAC_START=76,
		WRITEMAC_FAIL=77,
		WRITEMAC_PASS=78,
		READBT_START=79,
		READBT_FAIL=80,
		READBT_PASS=81,
		WRITEBT_START=82,
		WRITEBT_FAIL=83,
		WRITEBT_PASS=84,
		LOWERFORMAT_START=85,
		LOWERFORMAT_FAIL=86,
		LOWERFORMAT_PASS=87,
		READIMEI_START=88,
		READIMEI_FAIL=89,
		READIMEI_PASS=90,
		WRITEIMEI_START=91,
		WRITEIMEI_FAIL=92,
		WRITEIMEI_PASS=93,
		SHOWDATADISK_START=94,
		SHOWDATADISK_FAIL=95,
		SHOWDATADISK_PASS=96,
		FINDDATADISK_START=97,
		FINDDATADISK_FAIL=98,
		FINDDATADISK_PASS=99,
		FORMATDATADISK_START=100,
		FORMATDATADISK_FAIL=101,
		FORMATDATADISK_PASS=102,
		COPYDATADISK_START=103,
		COPYDATADISK_FAIL=104,
		COPYDATADISK_PASS=105,
		READUID_START=106,
		READUID_FAIL=107,
		READUID_PASS=108,
		READCUSTOMDATA_START=109,
		READCUSTOMDATA_FAIL=110,
		READCUSTOMDATA_PASS=111,
		WRITECUSTOMDATA_START=112,
		WRITECUSTOMDATA_FAIL=113,
		WRITECUSTOMDATA_PASS=114,
		SETRESETFLAG_START=115,
		SETRESETFLAG_FAIL=116,
		SETRESETFLAG_PASS=117,
		POWEROFF_START=118,
		POWEROFF_FAIL=119,
		POWEROFF_PASS=120,
		READALLINFO_START=121,
		READALLINFO_FAIL=122,
		READALLINFO_PASS=123,
		WRITEALLINFO_START=124,
		WRITEALLINFO_FAIL=125,
		WRITEALLINFO_PASS=126,
		RESETMSC_START=127,
		RESETMSC_FAIL=128,
		RESETMSC_PASS=129,
		READWIFI_START=130,
		READWIFI_FAIL=131,
		READWIFI_PASS=132,
		WRITEWIFI_START=133,
		WRITEWIFI_FAIL=134,
		WRITEWIFI_PASS=135,
		DOWNLOADDEMO_START=136,
		DOWNLOADDEMO_FAIL=137,
		DOWNLOADDEMO_PASS=138,
		CLEARSECTOR3_START=139,
		CLEARSECTOR3_FAIL=140,
		CLEARSECTOR3_PASS=141,
		DOWNDLOAD_START=142,
		RESETDEVICE_SUBCODE_START = 143,
		RESETDEVICE_SUBCODE_FAIL = 144,
		SWITCHUVC_START=145,
		SWITCHUVC_FAIL=146,
		SWITCHUVC_PASS=147,
}ENUM_UPGRADE_PROMPT;
typedef enum
{
	TESTDEVICE_PROGRESS,
	DOWNLOADIMAGE_PROGRESS,
	CHECKIMAGE_PROGRESS,
	TAGBADBLOCK_PROGRESS,
	TESTBLOCK_PROGRESS,
	ERASEFLASH_PROGRESS,
	ERASESYSTEM_PROGRESS,
	LOWERFORMAT_PROGRESS,
	ERASEUSERDATA_PROGRESS,
	DOWNLOADDEMO_PROGRESS,
	CHECKDEMO_PROGRESS
}ENUM_PROGRESS_PROMPT;
#define	MSC_SWITCHROCKUSB	0xFFFFFFFE
#define MSC_GETVERSIONINFO	0xFFFFFFFF
#define MSC_RESETDEVICE		0xFFFFFFFD
#define MSC_GETCHIPINFO		0xFFFFFFFC
#define MSC_SHOWUSERDISK	0xFFFFFFFB
#define MSC_GETDEVIVEUID	0xFFFFFFF7
#define MSC_SHOWDATADISK	0xFFFFFFF6
#define MSC_GETPRODUCTMODEL 0xFFFFFFF3
#define MSC_GETPARAMETER	0xFFFFFFF2
#define MSC_GETIDBSECTOR	0xFFFFFFF1
#define MSC_GETPRODUCTSN	0xFFFFFFEF
typedef enum
{
	CALL_FIRST,
	CALL_MIDDLE,
	CALL_LAST
}ENUM_CALL_STEP;
/*----------------------------------------------------------------------
Name    :   UpgradeStepPromptCB
Desc    :   Callback function for prompting upgrade step
Params  :   (IN)deviceLayer:			Device layer ID, used to distinguish devices
            (IN)promptID:				Used to specify state of certain upgrade step
            (IN)oldDeviceLayer			Reserved
Return  :   TRUE:						SUCCESSED
            FALSE:						FAILED
Notes   :   
----------------------------------------------------------------------*/
typedef VOID (*UpgradeStepPromptCB)(DWORD deviceLayer,ENUM_UPGRADE_PROMPT promptID,DWORD oldDeviceLayer);
/*----------------------------------------------------------------------
Name    :   UpgradeStepPromptCB
Desc    :   Callback function for prompting upgrade step which takes long time
Params  :   (IN)deviceLayer:			Device layer ID, used to distinguish devices
            (IN)promptID:				Used to specify progress of certain upgrade step
            (IN)totalValue				Total value, e.g. Flash capacity
			(IN)currentValue			Current value, e.g. Current block being erased
			(IN)emCall					Used for prompt, refer to routine
Return  :   TRUE:						SUCCESSED
            FALSE:						FAILED
Notes   :   
----------------------------------------------------------------------*/
typedef VOID (*ProgressPromptCB)(DWORD deviceLayer,ENUM_PROGRESS_PROMPT promptID,ULONG64 totalValue,ULONG64 currentValue,ENUM_CALL_STEP emCall);
#endif