//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by FactoryTool.rc
//
#define IDD_FACTORYTOOL_DIALOG          102
#define IDR_MAINFRAME                   128
#define IDB_BITMAP_GREENLED             137
#define IDB_BITMAP_DEMO                 139
#define IDB_BITMAP_FIRMWARE             140
#define IDB_BITMAP_RUN                  141
#define IDB_BITMAP_PAUSE                142
#define IDB_BITMAP_EXIT                 143
#define IDB_BITMAP_LANGUAGE             144
#define IDB_BITMAP_REDLED               145
#define IDB_TREEBTNS                    146
#define IDI_ICON_HUB                    147
#define IDI_ICON_MONITOR                148
#define IDI_ICON_PORT                   149
#define IDI_ICON_HOST                   150
#define IDI_ICON_PORT_OFF               152
#define IDI_ICON_FAIL                   153
#define IDI_ICON_SUCCESS                154
#define IDC_BUTTON_FIRMWARE             1000
#define IDC_BUTTON_RUN                  1001
#define IDC_BUTTON_DEMO                 1002
#define IDC_RADIO_UPGRADE               1003
#define IDC_RADIO_RESTORE               1004
#define IDC_BUTTON_LANGUAGE             1005
#define IDC_BUTTON_EXIT                 1006
#define IDC_EDIT_DEMO                   1007
#define IDC_EDIT_FIRMWARE               1008
#define IDC_TREE_DEVICEINFO             1012
#define IDC_STATIC_RUNOPTION            1013
#define IDC_STATIC_FIRMWARE             1014
#define IDC_STATIC_FWVERSION            1016
#define IDC_STATIC_LOADERVER            1017
#define IDC_STATIC_FWCHIP               1018
#define IDC_PICTURE_LED                 1019
#define IDC_STATIC_HELP                 1020
#define IDC_STATIC_GROUP1               1021
#define IDC_STATIC_GROUP2               1022
#define IDC_STATIC_GROUP3               1023
#define IDC_STATIC_GROUP4               1024
#define IDC_STATIC_GROUP5               1025
#define IDC_STATIC_GROUP6               1026
#define IDC_STATIC_GROUP7               1027
#define IDC_STATIC_GROUP8               1028
#define IDC_STATIC_GROUP9               1029
#define IDC_STATIC_GROUP10              1030
#define IDC_STATIC_GROUP11              1031
#define IDC_STATIC_GROUP12              1032
#define IDC_STATIC_INFO1                1033
#define IDC_STATIC_INFO2                1034
#define IDC_STATIC_INFO3                1035
#define IDC_STATIC_INFO4                1036
#define IDC_STATIC_INFO5                1037
#define IDC_STATIC_INFO6                1038
#define IDC_STATIC_INFO7                1039
#define IDC_STATIC_INFO8                1040
#define IDC_STATIC_INFO9                1041
#define IDC_STATIC_INFO10               1042
#define IDC_STATIC_INFO11               1043
#define IDC_STATIC_INFO12               1044
#define IDC_STATIC_HELPTEXT             1045
#define IDC_RESULT_GRID                 1046
#define IDC_OK_GRID                     1046
#define IDC_FAIL_GRID                   1047
#define IDC_STATIC_SUCCESS              1050
#define IDC_STATIC_SUCCESS_COUNT        1051
#define IDC_STATIC_FAIL                 1052
#define IDC_STATIC_FAIL_COUNT           1053
#define IDC_STATIC_TOTAL                1054
#define IDC_STATIC_TOTAL_COUNT          1055
#define IDC_CHECK_DEMO                  1056

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        157
#define _APS_NEXT_COMMAND_VALUE         32772
#define _APS_NEXT_CONTROL_VALUE         1057
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
