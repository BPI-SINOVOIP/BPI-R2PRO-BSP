#include "stdafx.h"
#include <vidcap.h>
#include <ks.h>
#include <ksproxy.h>
#include <ksmedia.h>
#include <cctype>
#include <algorithm>
#include <atlconv.h>
#include <amvideo.h>

#include <initguid.h>
#include <uuids.h>
#define TOLOWER(x) ((x >= L'A')&& (x <= L'Z')) ? (x - L'A' + L'a') : x;
#define TOUPPER(x) ((x >= L'a')&& (x <= L'z')) ? (x - L'a' + L'A') : x;
//--------------------------------------------------------------------------
// for uvc extension

//41769EA2-04DE-E347-8B2B-F4341AFF003B
#define GUID_EXTENSION_UNIT_ROCKCHIP {0x41769EA2, 0x04DE, 0xE347, 0x8B, 0x2B, 0xF4, 0x34, 0x1A, 0xFF, 0x00, 0x3B}

GUID PROPSETID_VIDCAP_EXTENSION_UNIT = GUID_EXTENSION_UNIT_ROCKCHIP;

HRESULT FindExtensionNode(IKsTopologyInfo* pIksTopologyInfo, 
	GUID extensionGuid, 
	DWORD* pNodeId) 
{ 
	DWORD numberOfNodes; 
	HRESULT hResult; 
	WCHAR wname[MAX_PATH];
	char  sname[MAX_PATH];
	DWORD namelen;
	HRESULT hr = S_OK;

	hResult = pIksTopologyInfo->get_NumNodes(&numberOfNodes); 
	if (SUCCEEDED(hResult)) 
	{ 
		DWORD i; 
		GUID nodeGuid; 
		for (i = 0; i < numberOfNodes; i++) 
		{ 
			DWORD cbName = 0;
			hr = pIksTopologyInfo->get_NodeName(i, NULL, 0, &cbName);

			hr = pIksTopologyInfo->get_NodeName(i, wname, cbName, &namelen);

			WideCharToMultiByte( CP_ACP, 0, wname, -1, sname, 256, NULL, NULL );

			// 			MessageBox(NULL, sname, "name", 0);

			if (SUCCEEDED(pIksTopologyInfo->get_NodeType(i, &nodeGuid))) 
			{ 
				if (IsEqualGUID(extensionGuid, nodeGuid)) 
				{       // Found the extension node 
					*pNodeId = i; 
					break; 
				} 
			} 


		} 

		if (i == numberOfNodes) 
		{       // Did not find the node 
			hResult = S_FALSE; 
		} 
	} 
	return hResult; 
}

HRESULT GetDevice(IBaseFilter** gottaFilter, const TCHAR *LinkName)
{
	int count = 0;
	BOOL done = false;
	WCHAR szDevPath[256] = {0};

	// Create the System Device Enumerator.
	ICreateDevEnum *pSysDevEnum = NULL;
	HRESULT hr = CoCreateInstance(CLSID_SystemDeviceEnum, NULL,
								   CLSCTX_INPROC_SERVER,
								   IID_ICreateDevEnum,
								   (void **)&pSysDevEnum);
	if (FAILED(hr)) {
		return hr;
	}
	// Obtain a class enumerator for the video input category.
	IEnumMoniker *pEnumCat = NULL;
	hr = pSysDevEnum->CreateClassEnumerator(CLSID_VideoInputDeviceCategory,
											&pEnumCat, 0);
	if (hr == S_OK) {
		// Enumerate the monikers.
		IMoniker *pMoniker = NULL;
		ULONG cFetched;

		while ((pEnumCat->Next(1, &pMoniker, &cFetched) == S_OK) && (!done)) {
			// Bind the first moniker to an object
			IPropertyBag *pPropBag;

			hr = pMoniker->BindToStorage(0, 0, IID_IPropertyBag, (void **)&pPropBag);
			if (SUCCEEDED(hr)) {
				// To retrieve the filter's friendly name, do the following:
				VARIANT varName;
				/* DevicePath */
				VariantInit(&varName);
				hr = pPropBag->Read(L"DevicePath", &varName, 0);
				if (FAILED(hr)) {
					VariantClear(&varName);
					pPropBag->Release();
					pPropBag = NULL;
					pMoniker->Release();
					pMoniker = NULL;
					continue;
				}
				//copy the name to nDeviceName & wDeviceName
				count = 0;
				while( varName.bstrVal[count] != 0x00 ) {
					szDevPath[count] = TOLOWER(varName.bstrVal[count]);
					count++;
				}
				if ( 0 != _tcsstr(szDevPath, LinkName)) { /* no rk device */
						hr = pMoniker->BindToObject(NULL, NULL, IID_IBaseFilter, (void**)gottaFilter);
						done = true;
				}
				VariantClear(&varName);
				pPropBag->Release();
				pPropBag = NULL;
				pMoniker->Release();
				pMoniker = NULL;
			}
		}
		pEnumCat->Release();
		pEnumCat = NULL;
	}
	pSysDevEnum->Release();
	pSysDevEnum = NULL;
	if (done) {
		return hr; // found it, return native error
	} else {
		return -1;	// didn't find it error
	}
}

BOOL SendData(IKsControl* pKsControl, int nPropertyID, int nNodeId, PUCHAR pBLock, int nBlockLen)
{
	KSP_NODE ExtensionProp;
	ULONG ulBytesReturned;
	HRESULT hr;
	ExtensionProp.Property.Set = PROPSETID_VIDCAP_EXTENSION_UNIT;
	ExtensionProp.Property.Id = nPropertyID;
	ExtensionProp.NodeId = nNodeId;

	ExtensionProp.Property.Flags = KSPROPERTY_TYPE_SET | KSPROPERTY_TYPE_TOPOLOGY;
	hr = pKsControl->KsProperty(
		(PKSPROPERTY) &ExtensionProp, 
		sizeof(ExtensionProp), 
		(PVOID) pBLock, 
		nBlockLen, 
		&ulBytesReturned);

	if(hr != S_OK)
	{
		return FALSE;
	}

	return TRUE;
}

bool extension_cmd(const TCHAR *szLinkName, int nPropertyID, PBYTE pData, UINT nLen)
{
	HRESULT hr = NULL;
	bool bRet = false;
	IKsTopologyInfo* pKsToplogyInfo;
	IKsControl *pKsControl = NULL;
	IBaseFilter *pVideoCaptureFilter = NULL;
	HRESULT hResult;
	DWORD dwNode = -1;
	int NodeId = -1;

	hr = GetDevice(&pVideoCaptureFilter, szLinkName);
	//hr = getDevice(&pVideoCaptureFilter, inputdev);
	if (SUCCEEDED(hr)) {
	} else {
		return false;
	}
	if (!pVideoCaptureFilter)
		return false;
	hResult = pVideoCaptureFilter->QueryInterface(__uuidof(IKsTopologyInfo), (void**)( &pKsToplogyInfo));
	if( S_OK == hResult ) {
		hResult = FindExtensionNode(pKsToplogyInfo, KSNODETYPE_DEV_SPECIFIC, &dwNode);
		pKsToplogyInfo->Release();
		if(S_OK == hResult) {
			NodeId = dwNode;
		} else {
			goto ErrorExit;
		}
	} else {
		goto ErrorExit;
	}
	hResult = pVideoCaptureFilter->QueryInterface(__uuidof(IKsControl),  (void **) &pKsControl);
	if (hResult != S_OK) {
		pKsControl = NULL;
		goto ErrorExit;
	}
	if (!SendData(pKsControl, nPropertyID, NodeId, pData, nLen)) {
		goto ErrorExit;
	}
	bRet = true;
ErrorExit:
	if(pVideoCaptureFilter != NULL) {
		pVideoCaptureFilter->Release();
		pVideoCaptureFilter = NULL;
	}
	if(pKsControl != NULL) {
		pKsControl->Release();
		pKsControl = NULL;
	}
	return bRet;
}

bool comInit()
{
	CoInitializeEx(NULL,COINIT_MULTITHREADED);
	return true;
}

bool comUnInit()
{
	CoUninitialize();	//if there are no instances left - uninitialize com
	return true;
}
