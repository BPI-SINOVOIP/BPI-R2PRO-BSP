#ifndef _RKSLUVC_UTILS_H_
#define _RKSLUVC_UTILS_H_

bool extension_cmd(const TCHAR *szLinkName, int nPropertyID, PBYTE pData, UINT nLen);
BOOL UVCSwitchToLoader(STRUCT_RKDEVICE_DESC *dev, ENUM_RKUSB_TYPE type);





#endif