* How to integrate to IOS application?

Copy libneeze.a & libcrypto.a & neeze.h to your project, and call send_neeze() in your code.

* Interface definition

Please refer to neeze.h for full information.

int send_neeze(const char* ssid, int ssid_len, /* ssid and len */
    const char* pwd, int pwd_len,  /* password and len */
    const char* key, int key_len,  /* encryption key and len, leave it "" to use default */
    unsigned int ip); /* ip address in network order */

To make it reliable, we'd better call send_neeze many times. 
  - ssid: AP's SSID
  - pwd: AP's password
  - key: encryption key. To use default encryption key, just leave it "" or NULL and set key_len to 0.
  - ip: IP address in network order, so for 192.168.1.1 it should be 0x0101a8c0
