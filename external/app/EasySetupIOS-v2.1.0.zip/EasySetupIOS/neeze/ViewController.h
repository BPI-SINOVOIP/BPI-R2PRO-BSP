//
//  ViewController.h
//  NEEZE
//
//  Created by apk on 2014/11/14.
//  Copyright (c) 2014年 NEEZE. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "neeze.h"
#import "Reachability.h"
@interface ViewController : UIViewController
@property (strong, nonatomic) IBOutlet UITextField *ssid;
@property (strong, nonatomic) IBOutlet UITextField *pwd;
@property (strong, nonatomic) IBOutlet UIButton *send_btn;


@end

