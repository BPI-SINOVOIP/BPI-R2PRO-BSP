#include <string.h>
#include <inttypes.h>

void dump_ssid_list(char* buf, int length) {
    int i = 0;
    int len = 0;
    char b[33] = {0};
    int8_t rssi = 0;
    int8_t sec = 0;
    while (i+2 < length) {
        /* 
         * A sequence of rssi-sec-len-ssid
         * octet[0]: rssi
         * octet[1]: secutiry (0=none, 1=wep, 2=wpa/wpa2-psk, 3=wpa2-enterprise)
         * octet[2]: ssid length
         * octet[3...]: ssid bytes
         */
        if (len == 0) {
            rssi = buf[i+0];
            sec = buf[i+1];
            len = buf[i+2];
            i += 3;
        } else {
            int alen = len; /* actual length (length to copy) */
            if (alen > sizeof(b)-1) {
                alen = sizeof(b)-1;
            }

            if (i+alen > length) break;

            memcpy(b, buf+i, alen);
            b[alen] = 0;
            printf("%d/%d/%s\n", rssi, sec, b);

            i += len;
            len = 0;
        }
    }
}

int main(int argc, char* argv[]) {
    char ssid[] = "Broadcom2g";
    char pwd[] = "12345678";
    char key[] = "";
    unsigned int ip = 0x0101a8c0; /* 192.168.1.1 */

    if (argc <= 1) {
        printf("usage: %s <0/1> (0 - es, 1 - softap)\n", argv[0]);
        return 0;
    }

    int softap = atoi(argv[1]);

    /* get ssid list */
    if (softap) {
        char buf[1024];
        int ret = listen_for_ssid_list(buf, sizeof(buf));
        if (ret > 0) {
            dump_ssid_list(buf, ret);
        } else {
            printf("no ssid list received\n");
        }
    }

    while (1) {
        if (softap) {
            send_to_ap_with_port(ssid, strlen(ssid), pwd, strlen(pwd), key, strlen(key), ip);
        } else {
            send_neeze(ssid, strlen(ssid), pwd, strlen(pwd), key, strlen(key), ip);
        }
    }

    return 0;
}
