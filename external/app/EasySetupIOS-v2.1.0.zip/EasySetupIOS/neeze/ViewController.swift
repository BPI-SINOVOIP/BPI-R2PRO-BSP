//
//  ViewController.swift
//  Broadcom EasySetup Demo
//
//  Created by david.peng@broadcom.com on 2/8/15.
//  Copyright (c) 2015 Broadcom. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    let ES:Int = 0
    let AP:Int = 1
    let switch_to_es = "Switch to ES sending"
    let switch_to_ap = "Switch to AP sending"
    let switch_mode_prompt_in_es = "SSID/PWD not received in long time? Connect to device SSID and click SWITCH."
    let switch_mode_prompt_in_ap = "Try normal sending? Leave device SSID, connect to normal SSID and click SWITCH."
    
    var wifiConnected = false {
        didSet {
            print("wifiConnected=\(wifiConnected)")
        }
    }
    var strSsid:String = ""
    var strPassword:String = ""
    var mMode = 0
    
    @IBOutlet weak var mFillssidView: UIView!
    @IBOutlet weak var mSendingView: UIView!
    
    @IBOutlet weak var ssid: UITextField!
    @IBOutlet weak var password: UITextField!
    
    @IBOutlet weak var mIndicator: UIActivityIndicatorView!
    @IBOutlet weak var mInfo: UITextView!
    @IBOutlet weak var mSwitchButton: UIButton!
    @IBOutlet weak var mStopButton: UIButton!
    
    var sendInProgress: Bool = false {
        didSet {
            if sendInProgress {
                mIndicator.startAnimating()
                print("start sending")
            } else {
                mIndicator.stopAnimating()
                print("end sending")
            }
        }
    }
    
    @IBOutlet weak var mBtn: UIButton!
    @IBAction func onToggleSend(_ sender: UIButton) {
        strSsid = ssid.text ?? ""
        print("ssid: \(strSsid)")
        strPassword = password.text ?? ""
        print("password: \(strPassword)")
        
        if !sendInProgress {
            if !wifiConnected {
                print("wifi not connected")
                
                presentAlert(title:"Error", message:"Wi-Fi not connected")
                return
            }
            
            print("wifi connected")
            sendInProgress = true
            
            DispatchQueue.global().async { () -> Void in
                while self.sendInProgress {
                    let ip: UInt32 = 0 // change to your ip (in network order, eg: 0x0201a8c0 (192.168.1.2)
                    let port: UInt32 = 1729 // port = 1729, change to your port
                    var ret:Int32 = -1
                    if self.mMode == self.ES {
                        print("es sending")
                        ret = send_neeze_with_port(self.strSsid, UInt32(strlen(self.strSsid)),
                                         self.strPassword, UInt32(strlen(self.strPassword)),
                                         "", 0, ip, port)
                    } else {
                        ret = send_to_ap_with_port(self.strSsid, UInt32(strlen(self.strSsid)),
                                             self.strPassword, UInt32(strlen(self.strPassword)),
                                             "", 0, ip, port)
                        print("ap sending")
                    }
                }
            }
            
            mFillssidView.isHidden = true
            mSendingView.isHidden = false
        }
    }
    
    @IBAction func onStop(_ sender: UIButton) {
        if sendInProgress {
            sendInProgress = false
            
            mFillssidView.isHidden = false
            mSendingView.isHidden = true
        }
    }
    
    @IBAction func onSwitch(_ sender: UIButton) {
        var ssid = getWifiSsid()
        ssid = "es"
        if ssid == nil {
            presentAlert(title: "Error", message: "Wi-Fi not connected")
            return
        }
        
        if mMode == ES {
            if ssid == "es" {
                mMode = AP
                mInfo.text = switch_mode_prompt_in_ap
                mSwitchButton.setTitle(switch_to_es, for: .normal)
            } else {
                presentAlert(title: "Error", message: switch_mode_prompt_in_es)
            }
        } else {
            if ssid != "es" {
                mMode = ES
                mInfo.text = switch_mode_prompt_in_es
                mSwitchButton.setTitle(switch_to_ap, for: .normal)
            } else {
                presentAlert(title: "Error", message: switch_mode_prompt_in_ap)
            }
        }
    }
    
    func presentAlert(title:String, message:String) -> Void {
        let controller = UIAlertController(title: title,
                                           message: message,
                                           preferredStyle: .alert)
        controller.addAction(UIAlertAction(title: "OK",
            style: .default,
            handler: nil))
        present(controller, animated: true, completion: nil)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        wifiConnected = checkWifiConnected()
        print("wifi connected=\(wifiConnected)")
        
        let s = getWifiSsid()
        if s != nil {
            print("ssid=\(s!)")
            ssid.text = getWifiSsid()
            
            if s == "es" {
                mMode = AP
                mInfo.text = switch_mode_prompt_in_ap
                mSwitchButton.setTitle(switch_to_es, for: UIControlState.normal)
            } else {
                mMode = ES
                mInfo.text = switch_mode_prompt_in_es
                mSwitchButton.setTitle(switch_to_ap, for: UIControlState.normal)
            }
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func checkWifiConnected() -> Bool {
        let status = Reachability.forLocalWiFi().currentReachabilityStatus()
        if status != NotReachable {
            return true
        } else {
            return false
        }
    }
    
    func getWifiSsid() -> String? {
        if !checkWifiConnected() {
            return nil
        }
        
        if let ifs:NSArray = CNCopySupportedInterfaces() {
            for x in ifs {
                if let dict = CFBridgingRetain(CNCopyCurrentNetworkInfo(x as! CFString)) {
                    let ssid = dict["SSID"]
                    return ssid as? String
                }
            }
        }
        
        return nil
    }
}

