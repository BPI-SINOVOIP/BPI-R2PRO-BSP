
#ifndef __NEEZE_H__
#define __NEEZE_H__

#include <inttypes.h>

/* set packet interval in ms. default 8ms */
int set_packet_interval(int ms);

/* send neeze */
int send_neeze(const char* ssid, uint32_t ssid_len, 
        const char* pwd, uint32_t pwd_len, 
        const char* key, uint32_t key_len,
        uint32_t ip);

/*
 * send ES
 * ssid, ssid_len: ssid passed to device
 * pwd, pwd_len: pwd passed to device
 * key, key_len: key to protect ssid/pwd
 * ip, port: passed to device, so device notify sender when it's connected to AP
 *   (note: ip is in big-endian/network order, so 0x0101a8c0 is for 192.168.1.1)
 *
 * For example:
 *   send_neeze_with_port("office-5g", 9, "12345678", 8, NULL, 0, 0x0201a8c0, 1729);
 * sends office-5g/12345678 to device, local IP is 192.168.1.2, port 1729, use the default encryption key
 */
int send_neeze_with_port(const char* ssid, uint32_t ssid_len, 
        const char* pwd, uint32_t pwd_len, 
        const char* key, uint32_t key_len,
        uint32_t ip, uint32_t port);

/*
 * send to soft AP
 * ssid, ssid_len: ssid passed to device
 * pwd, pwd_len: pwd passed to device
 * key, key_len: key to protect ssid/pwd
 * ip, port: passed to device, so device notify sender when it's connected to AP
 */
int send_to_ap_with_port(const char* ssid, uint32_t ssid_len, 
        const char* pwd, uint32_t pwd_len, 
        const char* key, uint32_t key_len,
        uint32_t ip, uint32_t port);

/*
 * listen for ssid list in softap mode
 * buf: buffer allocated by user to receive ssid list
 * buf_len: buffer length, 1024 bytes is suggested
 * returns the actual length of data received
 */
int listen_for_ssid_list(uint8_t* buf, uint32_t buf_len);

#endif /* __NEEZE_H__ */
