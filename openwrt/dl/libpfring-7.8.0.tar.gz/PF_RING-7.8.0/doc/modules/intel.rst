Intel Support
=============

Accelerated packet capture and trasmission for Intel adapters is available
on PF_RING ZC by means of specialised drivers as described in the 
`PF_RING ZC <https://www.ntop.org/guides/pf_ring/zc.html>`_ section.
Please also read `Installing from packages <https://www.ntop.org/guides/pf_ring/get_started/packages_installation.html>`_
for installation and configuration instructions.
