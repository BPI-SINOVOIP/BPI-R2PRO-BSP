#!/usr/bin/env python3

print('ext/noext')
