#!/usr/bin/env python3

import os
import sys

assert(os.path.exists(sys.argv[1]))
