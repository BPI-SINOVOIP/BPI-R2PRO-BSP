#include<iostream>

int main(int, char**) {
    std::cout << "I am C++.\n";
    return 0;
}
