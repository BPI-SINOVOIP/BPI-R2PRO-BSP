int func1();
int func2();

int main(int argc, char **argv) {
    return func1() - func2();
}
