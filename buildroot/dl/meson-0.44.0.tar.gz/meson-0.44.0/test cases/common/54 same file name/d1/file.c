int func1() { return 42; }
