/* This header goes to include dir root. */

int root_func();
