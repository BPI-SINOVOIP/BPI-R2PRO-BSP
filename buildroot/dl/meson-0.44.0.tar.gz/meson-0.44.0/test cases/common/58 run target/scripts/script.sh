#!/bin/sh

cd "$MESON_SOURCE_ROOT"
echo My current directory is `pwd`
echo Build dir is at $MESON_BUILD_ROOT
