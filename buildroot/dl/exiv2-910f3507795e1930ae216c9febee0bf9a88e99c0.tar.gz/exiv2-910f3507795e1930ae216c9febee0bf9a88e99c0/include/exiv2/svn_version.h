#ifndef SVN_VERSION
#define SVN_VERSION 0
#endif
