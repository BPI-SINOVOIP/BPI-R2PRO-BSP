#include"extractor.h"

int func1() {
    return 1;
}
