#ifdef MYTHING
#error "Wrong global argument set"
#endif

#ifndef MYCPPTHING
#error "Global argument not set"
#endif

#ifndef MYCANDCPPTHING
#error "Global argument not set"
#endif

int main(int argc, char **argv) {
    return 0;
}
