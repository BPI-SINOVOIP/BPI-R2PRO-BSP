static int duplicate_func() {
    return 4;
}

int func() {
    return duplicate_func();
}
