int dir2_dir1 = 21;
