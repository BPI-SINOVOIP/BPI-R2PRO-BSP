int dir3 = 30;
