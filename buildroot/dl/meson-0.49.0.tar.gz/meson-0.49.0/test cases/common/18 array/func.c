int func() { return 0; }
