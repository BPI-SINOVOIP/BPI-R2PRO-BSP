int custom_function() {
    return 42;
}
