int exposed_function() {
    return 42;
}
