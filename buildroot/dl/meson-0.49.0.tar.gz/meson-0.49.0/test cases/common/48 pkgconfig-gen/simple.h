#ifndef SIMPLE_H_
#define SIMPLE_H_

int simple_function();

#endif
