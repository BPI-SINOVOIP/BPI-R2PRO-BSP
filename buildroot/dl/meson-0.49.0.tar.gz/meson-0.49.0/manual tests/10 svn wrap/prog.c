#include"subproj.h"

int main(int argc, char **argv) {
    subproj_function();
    return 0;
}
