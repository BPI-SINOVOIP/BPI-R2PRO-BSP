.. _api:

API
===

:: Placeholder for Doxygen documentation
