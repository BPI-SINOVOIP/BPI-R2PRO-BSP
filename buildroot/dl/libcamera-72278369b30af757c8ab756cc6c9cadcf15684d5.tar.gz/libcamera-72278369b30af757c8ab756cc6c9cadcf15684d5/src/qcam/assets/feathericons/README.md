Icons from https://feathericons.com/
License: MIT

Generate the QRC file with:
 rcc --project
